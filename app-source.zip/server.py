import base64,hashlib,json,mimetypes,os,re,sqlite3
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit,unquote
ROOT=Path(__file__).parent; DATA=Path(os.environ.get('DATA_DIR',str(ROOT/'data'))); MAX_BODY=9*1024*1024

def connect():
 c=sqlite3.connect(DATA/'food.sqlite',timeout=15);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def initialize():
 DATA.mkdir(parents=True,exist_ok=True);(DATA/'uploads').mkdir(exist_ok=True)
 with connect() as c:
  c.execute('PRAGMA journal_mode=WAL');c.execute('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, sha TEXT NOT NULL)')
  for f in sorted((ROOT/'drizzle').glob('*.sql')):
   sha=hashlib.sha256(f.read_bytes()).hexdigest();done=c.execute('SELECT sha FROM schema_migrations WHERE name=?',(f.name,)).fetchone()
   if done:
    if done['sha']!=sha:raise RuntimeError('Applied migration changed')
    continue
   for statement in f.read_text().split('--> statement-breakpoint'):
    if statement.strip():c.execute(statement)
   c.execute('INSERT INTO schema_migrations VALUES (?,?)',(f.name,sha))
  for e in json.loads((ROOT/'seed-foods.json').read_text()):
   c.execute('INSERT OR IGNORE INTO foods(id,title,date,type,img,notes,jia,alison,version) VALUES(?,?,?,?,?,?,?,?,1)',tuple(e.get(k) for k in ['id','title','date','type','img','notes','jia','alison']))

def validate(e):
 if not isinstance(e,dict):raise ValueError('Invalid food')
 for k,maxlen in [('id',100),('title',120),('date',10),('type',20),('img',500),('notes',2000)]:
  if not isinstance(e.get(k),str) or len(e[k])>maxlen:raise ValueError('Invalid '+k)
 if not e['title'].strip() or not re.fullmatch(r'[\w-]+',e['id']):raise ValueError('Invalid food name or ID')
 import datetime
 datetime.date.fromisoformat(e['date'])
 if e['type'] not in ['unknown','recipe','restaurant']:raise ValueError('Invalid type')
 if not (re.fullmatch(r'/?assets/[\w.-]+',e['img']) or re.fullmatch(r'/uploads/[\w.-]+',e['img'])):raise ValueError('Invalid photo')
 for k in ['jia','alison']:
  v=e.get(k)
  if v is not None and (isinstance(v,bool) or not isinstance(v,(float,int)) or not 1<=v<=10):raise ValueError('Ratings must be between 1 and 10')
 return e

class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'dist'),**kwargs)
 def log_message(self,*args):pass
 def send_json(self,status,obj,headers=None):
  b=json.dumps(obj).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)))
  for k,v in (headers or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(b)
 def read_json(self):
  n=int(self.headers.get('Content-Length',0))
  if n<=0 or n>MAX_BODY:raise ValueError('Invalid request size')
  return json.loads(self.rfile.read(n))
 def same_origin(self):
  origin=self.headers.get('Origin');return not origin or urlsplit(origin).netloc==self.headers.get('Host')
 def do_GET(self):
  path=urlsplit(self.path).path
  if path=='/health':
   with connect() as c:c.execute('SELECT 1').fetchone()
   return self.send_json(200,{'ok':True})
  if path=='/api/foods':
   try:
    with connect() as c:rows=[dict(r) for r in c.execute('SELECT * FROM foods ORDER BY date DESC')]
    return self.send_json(200,{'entries':rows,'canEdit':True})
   except sqlite3.Error:return self.send_json(503,{'error':'Could not load foods. Please try again.'})
  if path.startswith('/uploads/'):
   filename=Path(unquote(path)).name
   if not re.fullmatch(r'[a-f0-9]{64}\.(jpg|png|webp)',filename):return self.send_json(404,{'error':'Not found'})
   p=DATA/'uploads'/filename
   if not p.is_file():return self.send_json(404,{'error':'Not found'})
   b=p.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(p)[0]);self.send_header('Content-Length',str(len(b)));self.send_header('X-Content-Type-Options','nosniff');self.end_headers();return self.wfile.write(b)
  if path!='/' and not path.startswith('/assets/'):return self.send_json(404,{'error':'Not found'})
  return super().do_GET()
 def do_POST(self):
  if not self.same_origin():return self.send_json(403,{'error':'Invalid origin'})
  path=urlsplit(self.path).path
  try:
   if path=='/api/upload':
    body=self.read_json();match=re.fullmatch(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',str(body.get('image','')))
    if not match:raise ValueError('Use a JPEG, PNG or WebP photo')
    b=base64.b64decode(match[2],validate=True)
    if len(b)>6*1024*1024:raise ValueError('Photo must be smaller than 6 MB')
    kind=match[1]
    if not ((kind=='jpeg' and b.startswith(b'\xff\xd8\xff')) or (kind=='png' and b.startswith(b'\x89PNG\r\n\x1a\n')) or (kind=='webp' and b.startswith(b'RIFF') and b[8:12]==b'WEBP')):raise ValueError('Invalid image')
    name=hashlib.sha256(b).hexdigest()+'.'+{'jpeg':'jpg','png':'png','webp':'webp'}[kind];(DATA/'uploads'/name).write_bytes(b)
    return self.send_json(200,{'img':'/uploads/'+name})
   if path=='/api/foods':
    e=validate(self.read_json())
    with connect() as c:
     row=c.execute('SELECT version FROM foods WHERE id=?',(e['id'],)).fetchone()
     if row:
      if e.get('version')!=row['version']:return self.send_json(409,{'error':'This food was updated on another device. Refresh before saving.'})
      result=c.execute('UPDATE foods SET title=?,date=?,type=?,img=?,notes=?,jia=?,alison=?,version=version+1 WHERE id=? AND version=?',tuple(e[k] for k in ['title','date','type','img','notes','jia','alison'])+(e['id'],e['version']))
      if result.rowcount!=1:return self.send_json(409,{'error':'This food was updated on another device.'})
     else:c.execute('INSERT INTO foods(id,title,date,type,img,notes,jia,alison,version) VALUES(?,?,?,?,?,?,?,?,1)',tuple(e.get(k) for k in ['id','title','date','type','img','notes','jia','alison']))
     saved=dict(c.execute('SELECT * FROM foods WHERE id=?',(e['id'],)).fetchone())
    return self.send_json(200,{'entry':saved})
   return self.send_json(404,{'error':'Not found'})
  except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e:return self.send_json(400,{'error':str(e)})
  except Exception as e:
   print('Storage request failed:',type(e).__name__,flush=True);return self.send_json(503,{'error':'Could not save. Please try again.'})

if __name__=='__main__':
 initialize();ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','3000'))),Handler).serve_forever()
