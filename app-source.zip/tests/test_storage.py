import base64,importlib.util,json,os,sqlite3,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('foodserver',Path(__file__).parents[1]/'server.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
class StorageTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DATA=Path(self.tmp.name);app.initialize()
 def tearDown(self):self.tmp.cleanup()
 def test_persistence_and_seed_idempotence(self):
  with app.connect() as c:c.execute('UPDATE foods SET jia=8.5,alison=9,version=2 WHERE id=?',('photo-5564',))
  app.initialize()
  with app.connect() as c:
   self.assertEqual(c.execute('SELECT COUNT(*) FROM foods').fetchone()[0],3)
   self.assertEqual(c.execute('SELECT jia,alison,version FROM foods WHERE id=?',('photo-5564',)).fetchone()[:],(8.5,9,2))
 def test_parameterized_titles_and_rating_limits(self):
  e=json.loads((app.ROOT/'seed-foods.json').read_text())[0];e['title']="Soup'); DROP TABLE foods; --";app.validate(e)
  with app.connect() as c:
   c.execute('UPDATE foods SET title=? WHERE id=?',(e['title'],e['id']));self.assertEqual(c.execute('SELECT COUNT(*) FROM foods').fetchone()[0],3)
  for rating in [0,11,True,float('nan')]:
   e['jia']=rating
   with self.assertRaises(ValueError):app.validate(e)
 def test_migration_history_is_immutable(self):
  with app.connect() as c:c.execute("UPDATE schema_migrations SET sha='changed'")
  with self.assertRaises(RuntimeError):app.initialize()
if __name__=='__main__':unittest.main()
