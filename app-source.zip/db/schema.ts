import {sqliteTable,text,real,integer} from 'drizzle-orm/sqlite-core';
export const foods=sqliteTable('foods',{id:text('id').primaryKey(),title:text('title').notNull(),date:text('date').notNull(),type:text('type').notNull(),img:text('img').notNull(),notes:text('notes').notNull().default(''),jia:real('jia'),alison:real('alison'),version:integer('version').notNull().default(1)});
