CREATE TABLE `foods` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`date` text NOT NULL,
	`type` text NOT NULL,
	`img` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`jia` real,
	`alison` real,
	`version` integer DEFAULT 1 NOT NULL
);
